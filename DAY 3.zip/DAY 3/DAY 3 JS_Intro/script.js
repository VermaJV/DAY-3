// console.log("Hello");

// console.log(message);  
// var message = "hello world";
// var age=10;
// console.log(age);
// age= "Done";
// console.log(message);
// console.log(age);

// function env(){
//     // console.log(message);
//     // var message = "helo world!!!!"
//     // console.log(message);
//     // message = "else";
//     // console.log(message);

// }
//--------------------------------
// function env()
// {
//     for(var i =0; i<5; i++)
//     {
//         console.log('--',i);
//     }
//     console.log(i);
// }

// env();
//----------------------------

// let ages= 10;
// console.log(typeof(ages));


// let arr= ['a','e', 'i','o','u'];
// arr[0] = 'abcd'; `
// console.log(arr);


// function print(str ='Nothing is here')
// {
//     console.log(str);
// }
// const s="hello";
// print(s);

function sum(a,b)
{   
    if(a && b)
    {
        console.log(a+b);
    }
    else{
        console.log(a);
    }
    console.log(a+b);
}
sum();

